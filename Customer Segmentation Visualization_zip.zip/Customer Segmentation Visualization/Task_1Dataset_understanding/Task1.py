# TASK 1:
# CODED BY PUNEET TIWARI
# DATE :8 AUG 2025

import pandas as pd



# Step 1: Load dataset 
dataset_path = r"D:\INTERNSHIP\SAIKET BI\Customer Segmentation Visualization\Task_1Dataset_understanding\Telco_Customer_Churn_Dataset.csv"
df = pd.read_csv(dataset_path)

# Step 2: Display first 10 rows
print("FIRST 10 ROWS OF THE DATASET")
print(df.head(10))

# Step 3: Identify the data types of each column
print("\nDATA TYPES OF EACH COLUMN")
print(df.dtypes)

# Step 4: Check for missing values
print("\nMISSING VALUES IN EACH COLUMN")
print(df.isnull().sum())