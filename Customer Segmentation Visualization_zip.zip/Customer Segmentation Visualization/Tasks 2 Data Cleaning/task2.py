# Task 2: Data Cleaning
#Dataset: TELCO_CUSTOMER_CHURN_DATASET.CSV
#coded by : puneet tiwari
#date: 14 august 2025


import pandas as pd

# Load original dataset
df= pd.read_csv(r"D:\INTERNSHIP\SAIKET BI\Customer Segmentation Visualization\Tasks 2 Data Cleaning\Telco_Customer_Churn_Dataset.csv")

# Step 1: Standardize column names
df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')

# Step 2: Handle missing/blank values in 'totalcharges'
# We focused on TotalCharges because it was the only problematic column in the dataset with blanks and wrong datatype.
df['totalcharges'] = df['totalcharges'].replace(" ", pd.NA)
df['totalcharges'] = pd.to_numeric(df['totalcharges'], errors='coerce')
df['totalcharges'] = df['totalcharges'].fillna(df['totalcharges'].median())


#Step 3: Remove duplicate rows
before = df.shape[0]
df.drop_duplicates(inplace=True)
after = df.shape[0]
duplicates_removed = before - after
print(f"Duplicates removed: {duplicates_removed}")

#Step 4: Standardize text values (remove spaces, lowercase) ---
for col in df.select_dtypes(include='object').columns:
    df[col] = df[col].str.strip().str.lower()

#  Final check
print("\n First 10 rows after cleaning ")
print(df.head(10))
print(f"\nFinal dataset shape: {df.shape[0]} rows, {df.shape[1]} columns")

# output in txt file
with open(r"D:\INTERNSHIP\SAIKET BI\Customer Segmentation Visualization\Tasks 2 Data Cleaning\task2_output.txt", "w") as f:
    f.write("First 10 rows after cleaning \n")
    f.write(str(df.head(10)))
    f.write(f"\n\nDuplicates removed: {duplicates_removed}")
    f.write(f"\nFinal dataset shape: {df.shape[0]} rows, {df.shape[1]} columns")

print("\nTask 2 output saved successfully!")

# Save cleaned dataset
df.to_csv(r"D:\INTERNSHIP\SAIKET BI\Customer Segmentation Visualization\Tasks 2 Data Cleaning\TASK2_CLEANED.CSV", index=False)
print("\nCleaned dataset saved successfully as Task2_Cleaned.csv!")

